import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { BookOpen, ChevronLeft, ChevronRight, Search, Languages } from "lucide-react";

export const Route = createFileRoute("/_authenticated/quran-digital")({
  head: () => ({ meta: [{ title: "Al-Qur'an Digital — SAQU Tahfidz" }] }),
  component: QuranDigitalPage,
});

type SurahListItem = {
  nomor: number; nama: string; namaLatin: string; jumlahAyat: number; tempatTurun: string; arti: string;
};
type Ayat = { nomorAyat: number; teksArab: string; teksLatin: string; teksIndonesia: string };
type SurahDetail = SurahListItem & { deskripsi: string; ayat: Ayat[]; suratSelanjutnya?: SurahListItem | false; suratSebelumnya?: SurahListItem | false };

function toArabicNum(n: number): string {
  const d = "٠١٢٣٤٥٦٧٨٩";
  return String(n).split("").map((c) => d[+c] ?? c).join("");
}

async function fetchSurahList(): Promise<SurahListItem[]> {
  const r = await fetch("https://equran.id/api/v2/surat");
  if (!r.ok) throw new Error("Gagal memuat daftar surah");
  const j = await r.json();
  return j.data;
}

async function fetchSurahDetail(nomor: number): Promise<SurahDetail> {
  const r = await fetch(`https://equran.id/api/v2/surat/${nomor}`);
  if (!r.ok) throw new Error("Gagal memuat surah");
  const j = await r.json();
  return j.data;
}

function QuranDigitalPage() {
  const [nomor, setNomor] = useState<number | null>(1);
  const [search, setSearch] = useState("");
  const [showTerjemahan, setShowTerjemahan] = useState(true);
  const [showLatin, setShowLatin] = useState(false);

  const { data: surahList, isLoading: loadingList } = useQuery({
    queryKey: ["equran-surat-list"],
    queryFn: fetchSurahList,
    staleTime: Infinity,
  });

  const { data: surah, isLoading: loadingSurah } = useQuery({
    queryKey: ["equran-surat", nomor],
    queryFn: () => fetchSurahDetail(nomor!),
    enabled: !!nomor,
  });

  const filtered = (surahList ?? []).filter((s) =>
    s.namaLatin.toLowerCase().includes(search.toLowerCase()) || s.arti.toLowerCase().includes(search.toLowerCase()) || String(s.nomor).includes(search)
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-extrabold flex items-center gap-2"><BookOpen className="h-7 w-7 text-sky" />Al-Qur'an Digital</h1>
        <p className="text-muted-foreground">Baca Al-Qur'an per surah dengan teks Arab Uthmani, terjemahan, dan transliterasi. Data diambil langsung dari equran.id.</p>
      </div>

      <div className="grid gap-4 lg:grid-cols-4">
        <Card className="card-fun lg:col-span-1">
          <CardContent className="p-3 space-y-3">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Cari surah..." className="pl-8" value={search} onChange={(e) => setSearch(e.target.value)} />
            </div>
            <div className="max-h-[65vh] space-y-1 overflow-y-auto pr-1">
              {loadingList && <p className="text-sm text-muted-foreground p-2">Memuat daftar surah...</p>}
              {filtered.map((s) => (
                <button
                  key={s.nomor}
                  onClick={() => setNomor(s.nomor)}
                  className={`w-full rounded-xl px-3 py-2 text-left text-sm transition ${nomor === s.nomor ? "bg-primary text-primary-foreground shadow" : "hover:bg-muted"}`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-semibold">{s.nomor}. {s.namaLatin}</span>
                    <span className="font-arabic text-base" dir="rtl">{s.nama}</span>
                  </div>
                  <div className={`text-xs ${nomor === s.nomor ? "text-primary-foreground/80" : "text-muted-foreground"}`}>{s.arti} · {s.jumlahAyat} ayat · {s.tempatTurun === "mekah" ? "Makkiyah" : "Madaniyah"}</div>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="card-fun lg:col-span-3">
          <CardContent className="p-5 space-y-5">
            {loadingSurah && <p className="text-center text-sm text-muted-foreground py-10">Memuat surah...</p>}
            {surah && (
              <>
                <div className="text-center space-y-1 border-b pb-4">
                  <div className="font-arabic text-4xl" dir="rtl">{surah.nama}</div>
                  <div className="font-display text-xl font-extrabold">{surah.namaLatin} — {surah.arti}</div>
                  <div className="text-xs text-muted-foreground">{surah.tempatTurun === "mekah" ? "Makkiyah" : "Madaniyah"} · {surah.jumlahAyat} Ayat</div>
                  <div className="flex justify-center gap-2 pt-2">
                    <Button size="sm" variant={showTerjemahan ? "default" : "outline"} className="rounded-lg text-xs" onClick={() => setShowTerjemahan((v) => !v)}>
                      <Languages className="mr-1 h-3 w-3" />Terjemahan
                    </Button>
                    <Button size="sm" variant={showLatin ? "default" : "outline"} className="rounded-lg text-xs" onClick={() => setShowLatin((v) => !v)}>Latin</Button>
                  </div>
                </div>

                {surah.nomor !== 1 && surah.nomor !== 9 && (
                  <p dir="rtl" className="font-arabic text-3xl text-center leading-loose text-foreground">
                    بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
                  </p>
                )}

                <div className="space-y-6">
                  {surah.ayat.map((a) => (
                    <div key={a.nomorAyat} className="border-b pb-4 last:border-0">
                      <p dir="rtl" lang="ar" className="font-arabic text-3xl leading-loose text-foreground text-right">
                        {a.teksArab}{" "}
                        <span className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-sky/20 text-base text-sky align-middle">
                          {toArabicNum(a.nomorAyat)}
                        </span>
                      </p>
                      {showLatin && <p className="mt-2 text-sm italic text-muted-foreground">{a.teksLatin}</p>}
                      {showTerjemahan && <p className="mt-1 text-sm">{a.nomorAyat}. {a.teksIndonesia}</p>}
                    </div>
                  ))}
                </div>

                <div className="flex items-center justify-between pt-2">
                  <Button
                    variant="outline" className="rounded-xl"
                    disabled={!surah.suratSebelumnya}
                    onClick={() => surah.suratSebelumnya && setNomor((surah.suratSebelumnya as SurahListItem).nomor)}
                  >
                    <ChevronLeft className="mr-1 h-4 w-4" />{surah.suratSebelumnya ? (surah.suratSebelumnya as SurahListItem).namaLatin : "Awal"}
                  </Button>
                  <Button
                    variant="outline" className="rounded-xl"
                    disabled={!surah.suratSelanjutnya}
                    onClick={() => surah.suratSelanjutnya && setNomor((surah.suratSelanjutnya as SurahListItem).nomor)}
                  >
                    {surah.suratSelanjutnya ? (surah.suratSelanjutnya as SurahListItem).namaLatin : "Akhir"}<ChevronRight className="ml-1 h-4 w-4" />
                  </Button>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
