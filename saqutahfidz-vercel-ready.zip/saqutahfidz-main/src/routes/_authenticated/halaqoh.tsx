import { createFileRoute } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useSession, useIsAdmin } from "@/lib/use-auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Plus, Pencil, UserMinus } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/halaqoh")({
  head: () => ({ meta: [{ title: "Halaqoh & Absensi — SAQU" }] }),
  component: HalaqohPage,
});

const HARI = ["Ahad", "Senin", "Selasa", "Rabu", "Kamis", "Jum'at", "Sabtu"];

function HalaqohPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-extrabold">Halaqoh & Absensi</h1>
        <p className="text-muted-foreground">Kelompok halaqoh, jadwal, dan absensi harian santri.</p>
      </div>
      <Tabs defaultValue="halaqoh">
        <TabsList className="rounded-xl">
          <TabsTrigger value="halaqoh">Halaqoh</TabsTrigger>
          <TabsTrigger value="musyrif">Musyrif & Pencapaian</TabsTrigger>
          <TabsTrigger value="absensi">Absensi Harian</TabsTrigger>
        </TabsList>
        <TabsContent value="halaqoh"><HalaqohTab /></TabsContent>
        <TabsContent value="musyrif"><MusyrifTab /></TabsContent>
        <TabsContent value="absensi"><AbsensiTab /></TabsContent>
      </Tabs>
    </div>
  );
}

function HalaqohTab() {
  const qc = useQueryClient();
  const isAdmin = useIsAdmin();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: "", level: "1", description: "" });
  const { data: rows } = useQuery({
    queryKey: ["halaqoh-full"],
    queryFn: async () => (await supabase.from("halaqoh").select("*, profiles:musyrif_id(full_name)").order("name")).data ?? [],
  });
  const add = useMutation({
    mutationFn: async () => { const { error } = await supabase.from("halaqoh").insert(form); if (error) throw error; },
    onSuccess: () => { toast.success("Halaqoh dibuat"); setOpen(false); qc.invalidateQueries({ queryKey: ["halaqoh-full"] }); qc.invalidateQueries({ queryKey: ["halaqoh"] }); },
    onError: (e: any) => toast.error(e.message),
  });

  return (
    <div className="space-y-4">
      {isAdmin && (
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button className="rounded-xl"><Plus className="mr-2 h-4 w-4" />Tambah Halaqoh</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Halaqoh Baru</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div><Label>Nama</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Halaqoh Al-Fatih" /></div>
              <div>
                <Label>Tingkat / Kelas</Label>
                <Select value={form.level} onValueChange={(v) => setForm({ ...form, level: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{["1","2","3","4","5","6"].map(k => <SelectItem key={k} value={k}>Kelas {k}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label>Keterangan</Label><Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
            </div>
            <DialogFooter><Button onClick={() => add.mutate()} disabled={add.isPending}>Simpan</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      )}
      <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
        {(rows ?? []).map((h: any) => (
          <Card key={h.id} className="card-fun">
            <CardContent className="p-5">
              <div className="font-display font-extrabold text-lg">{h.name}</div>
              <div className="text-xs text-muted-foreground">Kelas {h.level ?? "-"}</div>
              <div className="mt-1 text-xs font-semibold text-primary">
                Ustadz/ah: {h.profiles?.full_name ?? <span className="text-muted-foreground font-normal">belum ditentukan</span>}
              </div>
              {h.description && <p className="mt-2 text-sm">{h.description}</p>}
            </CardContent>
          </Card>
        ))}
        {(rows ?? []).length === 0 && <p className="text-sm text-muted-foreground">Belum ada halaqoh.</p>}
      </div>
    </div>
  );
}

const JENIS_LABEL: Record<string, string> = { ziyadah: "Ziyadah", murojaah: "Muroja'ah", tasmi: "Tasmi'", tahsin: "Tahsin" };
const JENIS_COLOR: Record<string, string> = {
  ziyadah: "bg-leaf/20 text-leaf", murojaah: "bg-sun/30 text-sun-foreground",
  tasmi: "bg-sky/20 text-sky", tahsin: "bg-berry/20 text-berry",
};

function MusyrifTab() {
  const qc = useQueryClient();
  const [halaqohId, setHalaqohId] = useState<string>("");
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [editingStudent, setEditingStudent] = useState<string | null>(null);

  const { data: halaqoh } = useQuery({
    queryKey: ["halaqoh-full"],
    queryFn: async () => (await supabase.from("halaqoh").select("*, profiles:musyrif_id(full_name)").order("name")).data ?? [],
  });

  const { data: santri } = useQuery({
    queryKey: ["santri-hal", halaqohId],
    enabled: !!halaqohId,
    queryFn: async () => (await supabase.from("students").select("id, full_name, nis").eq("halaqoh_id", halaqohId).order("full_name")).data ?? [],
  });

  const pindahHalaqoh = useMutation({
    mutationFn: async ({ studentId, newHalaqohId }: { studentId: string; newHalaqohId: string | null }) => {
      const { error } = await supabase.from("students").update({ halaqoh_id: newHalaqohId }).eq("id", studentId);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Halaqoh santri diperbarui");
      setEditingStudent(null);
      qc.invalidateQueries({ queryKey: ["santri-hal"] });
    },
    onError: (e: any) => toast.error(e.message),
  });

  const studentIds = (santri ?? []).map((s: any) => s.id);

  const { data: pencapaian } = useQuery({
    queryKey: ["pencapaian-harian", halaqohId, date],
    enabled: !!halaqohId && studentIds.length > 0,
    queryFn: async () => {
      const [ziy, mur, tas, tah] = await Promise.all([
        supabase.from("ziyadah_entries").select("student_id, juz, surah, ayat_from, ayat_to, notes").eq("date", date).in("student_id", studentIds),
        supabase.from("murojaah_entries").select("student_id, juz, surah_from, surah_to, notes").eq("date", date).in("student_id", studentIds),
        supabase.from("tasmi_entries").select("student_id, juz, surah_from, surah_to, notes").eq("date", date).in("student_id", studentIds),
        supabase.from("tahsin_entries" as any).select("student_id, juz, surah, ayat_from, ayat_to, notes").eq("date", date).in("student_id", studentIds),
      ]);
      const rows: any[] = [];
      (ziy.data ?? []).forEach((r: any) => rows.push({ ...r, jenis: "ziyadah", materi: `${r.surah} ${r.ayat_from}-${r.ayat_to}` }));
      (mur.data ?? []).forEach((r: any) => rows.push({ ...r, jenis: "murojaah", materi: `${r.surah_from}${r.surah_to ? " – " + r.surah_to : ""}` }));
      (tas.data ?? []).forEach((r: any) => rows.push({ ...r, jenis: "tasmi", materi: `${r.surah_from}${r.surah_to ? " – " + r.surah_to : ""}` }));
      (tah.data ?? []).forEach((r: any) => rows.push({ ...r, jenis: "tahsin", materi: `${r.surah} ${r.ayat_from ?? ""}-${r.ayat_to ?? ""}` }));
      return rows;
    },
  });

  const rowsByStudent = (sid: string) => (pencapaian ?? []).filter((r: any) => r.student_id === sid);
  const selectedHalaqoh = (halaqoh ?? []).find((h: any) => h.id === halaqohId);

  return (
    <div className="space-y-4">
      <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
        {(halaqoh ?? []).map((h: any) => (
          <button key={h.id} onClick={() => setHalaqohId(h.id)} className="text-left">
            <Card className={`card-fun transition-all ${halaqohId === h.id ? "ring-2 ring-primary" : "hover:shadow-md"}`}>
              <CardContent className="p-5">
                <div className="font-display font-extrabold text-lg">{h.name}</div>
                <div className="text-sm font-semibold text-primary">
                  {h.profiles?.full_name ?? <span className="text-muted-foreground font-normal">Ustadz/ah belum ditentukan</span>}
                </div>
              </CardContent>
            </Card>
          </button>
        ))}
        {(halaqoh ?? []).length === 0 && <p className="text-sm text-muted-foreground">Belum ada halaqoh.</p>}
      </div>

      {halaqohId && (
        <Card className="card-fun">
          <CardHeader className="flex flex-wrap items-center justify-between gap-3">
            <CardTitle>
              {selectedHalaqoh?.name} — {selectedHalaqoh?.profiles?.full_name ?? "Belum ada ustadz"}
            </CardTitle>
            <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="w-40" />
          </CardHeader>
          <CardContent className="space-y-2">
            {(santri ?? []).length === 0 && <p className="text-sm text-muted-foreground">Belum ada santri di halaqoh ini.</p>}
            {(santri ?? []).map((s: any) => {
              const entries = rowsByStudent(s.id);
              const sudahSetor = entries.some((e: any) => e.jenis !== "tahsin");
              return (
                <div key={s.id} className="rounded-xl border bg-muted/20 px-3 py-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="font-semibold">{s.full_name} <span className="text-xs text-muted-foreground font-normal">({s.nis})</span></div>
                    <div className="flex items-center gap-2">
                      <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold uppercase ${sudahSetor ? "bg-leaf/20 text-leaf" : "bg-berry/20 text-berry"}`}>
                        {sudahSetor ? "Sudah Setor" : "Belum Setor"}
                      </span>
                      <Button size="sm" variant="ghost" className="h-7 w-7 p-0 rounded-lg" onClick={() => setEditingStudent(editingStudent === s.id ? null : s.id)}>
                        <Pencil className="h-3.5 w-3.5" />
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button size="sm" variant="ghost" className="h-7 w-7 p-0 rounded-lg text-berry"><UserMinus className="h-3.5 w-3.5" /></Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Keluarkan {s.full_name} dari halaqoh ini?</AlertDialogTitle>
                            <AlertDialogDescription>Santri tidak akan dihapus dari sistem, hanya dilepas dari halaqoh ini. Kamu bisa memasukkannya ke halaqoh lain kapan saja.</AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Batal</AlertDialogCancel>
                            <AlertDialogAction className="bg-berry hover:bg-berry/90" onClick={() => pindahHalaqoh.mutate({ studentId: s.id, newHalaqohId: null })}>Keluarkan</AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                  {editingStudent === s.id && (
                    <div className="mt-2 flex items-center gap-2">
                      <span className="text-xs text-muted-foreground">Pindahkan ke halaqoh:</span>
                      <Select onValueChange={(v) => pindahHalaqoh.mutate({ studentId: s.id, newHalaqohId: v })}>
                        <SelectTrigger className="h-8 w-52 text-xs"><SelectValue placeholder="Pilih halaqoh tujuan" /></SelectTrigger>
                        <SelectContent>
                          {(halaqoh ?? []).filter((h: any) => h.id !== halaqohId).map((h: any) => <SelectItem key={h.id} value={h.id}>{h.name}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                  {entries.length > 0 && (
                    <div className="mt-2 space-y-1">
                      {entries.map((e: any, i: number) => (
                        <div key={i} className="flex flex-wrap items-center gap-2 text-xs">
                          <span className={`rounded-full px-2 py-0.5 font-bold uppercase ${JENIS_COLOR[e.jenis]}`}>{JENIS_LABEL[e.jenis]}</span>
                          <span>Juz {e.juz ?? "-"} · {e.materi}</span>
                          {e.notes && <span className="text-muted-foreground italic">— {e.notes}</span>}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function AbsensiTab() {
  const qc = useQueryClient();
  const { user } = useSession();
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [halaqohId, setHalaqohId] = useState<string>("");
  const [noteDraft, setNoteDraft] = useState<Record<string, string>>({});

  const { data: halaqoh } = useQuery({
    queryKey: ["halaqoh"],
    queryFn: async () => (await supabase.from("halaqoh").select("id, name").order("name")).data ?? [],
  });
  const { data: santri } = useQuery({
    queryKey: ["santri-hal", halaqohId],
    enabled: !!halaqohId,
    queryFn: async () => (await supabase.from("students").select("id, full_name").eq("halaqoh_id", halaqohId).order("full_name")).data ?? [],
  });
  const { data: abs } = useQuery({
    queryKey: ["absensi", date, halaqohId],
    enabled: !!halaqohId,
    queryFn: async () => {
      const ids = (santri ?? []).map((s: any) => s.id);
      if (ids.length === 0) return [];
      return (await supabase.from("attendance").select("*").eq("date", date).in("student_id", ids)).data ?? [];
    },
  });

  const mark = useMutation({
    mutationFn: async ({ student_id, status, notes }: { student_id: string; status: string; notes?: string }) => {
      const { error } = await supabase.from("attendance").upsert(
        { student_id, date, status: status as any, recorded_by: user!.id, notes: notes ?? null },
        { onConflict: "student_id,date" }
      );
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["absensi", date, halaqohId] }),
    onError: (e: any) => toast.error(e.message),
  });

  const getStatus = (sid: string) => (abs ?? []).find((a: any) => a.student_id === sid)?.status;
  const getNotes = (sid: string) => (abs ?? []).find((a: any) => a.student_id === sid)?.notes ?? "";

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end gap-3">
        <div>
          <Label>Tanggal</Label>
          <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        </div>
        <div className="min-w-56">
          <Label>Halaqoh</Label>
          <Select value={halaqohId} onValueChange={setHalaqohId}>
            <SelectTrigger><SelectValue placeholder="Pilih halaqoh" /></SelectTrigger>
            <SelectContent>{(halaqoh ?? []).map((h: any) => <SelectItem key={h.id} value={h.id}>{h.name}</SelectItem>)}</SelectContent>
          </Select>
        </div>
      </div>

      {halaqohId ? (
        <Card className="card-fun">
          <CardHeader><CardTitle>Daftar Santri — {date}</CardTitle></CardHeader>
          <CardContent>
            <div className="space-y-2">
              {(santri ?? []).map((s: any) => {
                const st = getStatus(s.id);
                const savedNotes = getNotes(s.id);
                const draft = noteDraft[s.id] ?? savedNotes;
                return (
                  <div key={s.id} className="rounded-xl border bg-muted/20 px-3 py-2 space-y-2">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="font-semibold">{s.full_name}</div>
                      <div className="flex gap-1">
                        {[["hadir","H","bg-leaf"],["izin","I","bg-sun"],["sakit","S","bg-sky"],["alpa","A","bg-berry"]].map(([v, l, c]) => (
                          <Button key={v} size="sm" variant={st === v ? "default" : "outline"}
                            onClick={() => mark.mutate({ student_id: s.id, status: v, notes: v === "hadir" ? undefined : (noteDraft[s.id] ?? savedNotes) })}
                            className={`rounded-lg w-10 ${st === v ? c + " text-white" : ""}`}>{l}</Button>
                        ))}
                      </div>
                    </div>
                    {st && st !== "hadir" && (
                      <div className="flex items-center gap-2">
                        <Input
                          placeholder={`Keterangan (alasan ${st})...`}
                          value={draft}
                          onChange={(e) => setNoteDraft({ ...noteDraft, [s.id]: e.target.value })}
                          className="h-8 text-xs"
                        />
                        <Button
                          size="sm" variant="ghost" className="h-8 rounded-lg text-xs shrink-0"
                          onClick={() => mark.mutate({ student_id: s.id, status: st, notes: noteDraft[s.id] ?? savedNotes })}
                        >Simpan</Button>
                      </div>
                    )}
                  </div>
                );
              })}
              {(santri ?? []).length === 0 && <p className="text-sm text-muted-foreground">Belum ada santri di halaqoh ini.</p>}
            </div>
          </CardContent>
        </Card>
      ) : (
        <p className="text-sm text-muted-foreground">Pilih halaqoh untuk mulai absensi.</p>
      )}
    </div>
  );
}
