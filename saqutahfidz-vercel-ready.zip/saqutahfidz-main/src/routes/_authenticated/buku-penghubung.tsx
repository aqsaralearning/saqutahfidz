import { createFileRoute } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useSession } from "@/lib/use-auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useState } from "react";
import { toast } from "sonner";
import { Heart, AlertTriangle } from "lucide-react";

export const Route = createFileRoute("/_authenticated/buku-penghubung")({
  head: () => ({ meta: [{ title: "Buku Penghubung — SAQU Tahfidz" }] }),
  component: BukuPenghubungPage,
});

const SHALAT_KEYS = ["shalat_subuh", "shalat_dzuhur", "shalat_ashar", "shalat_maghrib", "shalat_isya"] as const;
const SHALAT_LABEL: Record<string, string> = { shalat_subuh: "Subuh", shalat_dzuhur: "Dzuhur", shalat_ashar: "Ashar", shalat_maghrib: "Maghrib", shalat_isya: "Isya" };
const JENIS_PELANGGARAN = ["Tidak Setoran", "Main-main Saat Menghafal", "Terlambat Halaqoh", "Tidak Mengerjakan Tugas", "Lainnya"];

function BukuPenghubungPage() {
  const qc = useQueryClient();
  const { user } = useSession();
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [halaqohId, setHalaqohId] = useState("");
  const [drafts, setDrafts] = useState<Record<string, any>>({});
  const [pelanggaranForm, setPelanggaranForm] = useState<{ studentId: string; jenis: string; poin: number; catatan: string } | null>(null);

  const { data: halaqoh } = useQuery({
    queryKey: ["halaqoh-full"],
    queryFn: async () => (await supabase.from("halaqoh").select("*").order("name")).data ?? [],
  });

  const { data: santri } = useQuery({
    queryKey: ["santri-hal", halaqohId],
    enabled: !!halaqohId,
    queryFn: async () => (await supabase.from("students").select("id, full_name, nis").eq("halaqoh_id", halaqohId).order("full_name")).data ?? [],
  });

  const studentIds = (santri ?? []).map((s: any) => s.id);

  const { data: existing } = useQuery({
    queryKey: ["buku-penghubung", date, halaqohId],
    enabled: studentIds.length > 0,
    queryFn: async () => (await supabase.from("buku_penghubung" as any).select("*").eq("date", date).in("student_id", studentIds)).data ?? [],
  });

  const { data: pelanggaranHariIni } = useQuery({
    queryKey: ["pelanggaran-list", date, halaqohId],
    enabled: studentIds.length > 0,
    queryFn: async () => (await supabase.from("pelanggaran" as any).select("*").eq("date", date).in("student_id", studentIds)).data ?? [],
  });

  const getExisting = (sid: string) => (existing ?? []).find((e: any) => e.student_id === sid);
  const getDraft = (sid: string) => {
    if (drafts[sid]) return drafts[sid];
    const e = getExisting(sid);
    return {
      shalat_subuh: e?.shalat_subuh ?? false, shalat_dzuhur: e?.shalat_dzuhur ?? false, shalat_ashar: e?.shalat_ashar ?? false,
      shalat_maghrib: e?.shalat_maghrib ?? false, shalat_isya: e?.shalat_isya ?? false,
      tilawah_rumah: e?.tilawah_rumah ?? false, kebaikan: e?.kebaikan ?? "",
    };
  };
  const setDraft = (sid: string, patch: any) => setDrafts({ ...drafts, [sid]: { ...getDraft(sid), ...patch } });

  const save = useMutation({
    mutationFn: async (student_id: string) => {
      const d = getDraft(student_id);
      const { error } = await supabase.from("buku_penghubung" as any).upsert(
        { student_id, date, recorded_by: user!.id, ...d },
        { onConflict: "student_id,date" }
      );
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Buku penghubung disimpan"); qc.invalidateQueries({ queryKey: ["buku-penghubung", date, halaqohId] }); },
    onError: (e: any) => toast.error(e.message),
  });

  const addPelanggaran = useMutation({
    mutationFn: async () => {
      if (!pelanggaranForm) return;
      const { error } = await supabase.from("pelanggaran" as any).insert({
        student_id: pelanggaranForm.studentId, date, jenis: pelanggaranForm.jenis,
        poin: pelanggaranForm.poin, catatan: pelanggaranForm.catatan || null, recorded_by: user!.id,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Pelanggaran dicatat");
      setPelanggaranForm(null);
      qc.invalidateQueries({ queryKey: ["pelanggaran-list", date, halaqohId] });
    },
    onError: (e: any) => toast.error(e.message),
  });

  const pelanggaranBySantri = (sid: string) => (pelanggaranHariIni ?? []).filter((p: any) => p.student_id === sid);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-extrabold">Buku Penghubung & Pelanggaran</h1>
        <p className="text-muted-foreground">Catatan harian shalat, tilawah rumah, perbuatan baik, dan poin pelanggaran santri.</p>
      </div>

      <Card className="card-fun">
        <CardContent className="p-4 flex flex-wrap gap-3">
          <div>
            <Label>Tanggal</Label>
            <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="w-40" />
          </div>
          <div className="min-w-56">
            <Label>Halaqoh</Label>
            <Select value={halaqohId} onValueChange={setHalaqohId}>
              <SelectTrigger><SelectValue placeholder="Pilih halaqoh" /></SelectTrigger>
              <SelectContent>{(halaqoh ?? []).map((h: any) => <SelectItem key={h.id} value={h.id}>{h.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {halaqohId && (
        <div className="space-y-3">
          {(santri ?? []).map((s: any) => {
            const d = getDraft(s.id);
            const pel = pelanggaranBySantri(s.id);
            return (
              <Card key={s.id} className="card-fun">
                <CardContent className="p-4 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="font-semibold">{s.full_name} <span className="text-xs text-muted-foreground font-normal">({s.nis})</span></div>
                    <Button size="sm" variant="outline" className="rounded-lg text-xs" onClick={() => setPelanggaranForm({ studentId: s.id, jenis: JENIS_PELANGGARAN[0], poin: 1, catatan: "" })}>
                      <AlertTriangle className="mr-1 h-3 w-3" />Catat Pelanggaran
                    </Button>
                  </div>

                  <div className="flex flex-wrap gap-3">
                    {SHALAT_KEYS.map((k) => (
                      <label key={k} className="flex items-center gap-1.5 text-sm">
                        <Checkbox checked={d[k]} onCheckedChange={(v) => setDraft(s.id, { [k]: !!v })} />{SHALAT_LABEL[k]}
                      </label>
                    ))}
                    <label className="flex items-center gap-1.5 text-sm">
                      <Checkbox checked={d.tilawah_rumah} onCheckedChange={(v) => setDraft(s.id, { tilawah_rumah: !!v })} />Tilawah di Rumah
                    </label>
                  </div>

                  <div className="flex items-end gap-2">
                    <div className="flex-1">
                      <Label className="flex items-center gap-1 text-xs"><Heart className="h-3 w-3 text-berry" />Catatan Perbuatan Baik</Label>
                      <Textarea rows={2} value={d.kebaikan} onChange={(e) => setDraft(s.id, { kebaikan: e.target.value })} placeholder="Contoh: membantu teman, jujur mengembalikan barang, dst." />
                    </div>
                    <Button size="sm" className="rounded-lg" onClick={() => save.mutate(s.id)} disabled={save.isPending}>Simpan</Button>
                  </div>

                  {pel.length > 0 && (
                    <div className="space-y-1 border-t pt-2">
                      {pel.map((p: any) => (
                        <div key={p.id} className="flex items-center justify-between text-xs">
                          <span>⚠️ {p.jenis}{p.catatan ? ` — ${p.catatan}` : ""}</span>
                          <span className="rounded-full bg-berry/20 px-2 py-0.5 font-bold text-berry">-{p.poin} poin</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {pelanggaranForm?.studentId === s.id && (
                    <div className="space-y-2 rounded-xl border bg-berry/5 p-3">
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <Label className="text-xs">Jenis Pelanggaran</Label>
                          <Select value={pelanggaranForm.jenis} onValueChange={(v) => setPelanggaranForm({ ...pelanggaranForm, jenis: v })}>
                            <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                            <SelectContent>{JENIS_PELANGGARAN.map((j) => <SelectItem key={j} value={j}>{j}</SelectItem>)}</SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label className="text-xs">Poin</Label>
                          <Input type="number" min={1} className="h-8 text-xs" value={pelanggaranForm.poin} onChange={(e) => setPelanggaranForm({ ...pelanggaranForm, poin: +e.target.value })} />
                        </div>
                      </div>
                      <Input placeholder="Catatan (opsional)" className="h-8 text-xs" value={pelanggaranForm.catatan} onChange={(e) => setPelanggaranForm({ ...pelanggaranForm, catatan: e.target.value })} />
                      <div className="flex gap-2">
                        <Button size="sm" className="h-8 rounded-lg text-xs" onClick={() => addPelanggaran.mutate()} disabled={addPelanggaran.isPending}>Simpan Pelanggaran</Button>
                        <Button size="sm" variant="ghost" className="h-8 rounded-lg text-xs" onClick={() => setPelanggaranForm(null)}>Batal</Button>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
          {(santri ?? []).length === 0 && <p className="text-sm text-muted-foreground">Belum ada santri di halaqoh ini.</p>}
        </div>
      )}
    </div>
  );
}
