import { createFileRoute, redirect, useNavigate } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LogOut, BookOpen, Heart, AlertTriangle, GraduationCap } from "lucide-react";
import logoSaqu from "@/assets/logo-saqu.png.asset.json";
import { useSignedPhoto } from "@/lib/photo";

export const Route = createFileRoute("/wali")({
  ssr: false,
  head: () => ({ meta: [{ title: "Portal Wali Santri — SAQU Tahfidz" }] }),
  beforeLoad: async () => {
    const { data } = await supabase.auth.getUser();
    if (!data.user) throw redirect({ to: "/auth" });
  },
  component: WaliDashboard,
});

function WaliDashboard() {
  const nav = useNavigate();
  const qc = useQueryClient();
  const [studentId, setStudentId] = useState("");

  const { data: anak } = useQuery({
    queryKey: ["wali-anak"],
    queryFn: async () => (await supabase.from("parent_students").select("students(id, full_name, nis, class_level, gender, target_juz, photo_url, halaqoh(name))")).data ?? [],
  });

  const list = (anak ?? []).map((a: any) => a.students).filter(Boolean);
  const active = list.find((s: any) => s.id === studentId) ?? list[0];
  const photoUrl = useSignedPhoto(active?.photo_url);

  const { data: exams } = useQuery({
    queryKey: ["wali-exams", active?.id],
    enabled: !!active?.id,
    queryFn: async () => (await supabase.from("exams").select("*").eq("student_id", active.id).order("date", { ascending: false })).data ?? [],
  });

  const { data: buku } = useQuery({
    queryKey: ["wali-buku", active?.id],
    enabled: !!active?.id,
    queryFn: async () => (await supabase.from("buku_penghubung" as any).select("*").eq("student_id", active.id).order("date", { ascending: false }).limit(14)).data ?? [],
  });

  const { data: pelanggaran } = useQuery({
    queryKey: ["wali-pelanggaran", active?.id],
    enabled: !!active?.id,
    queryFn: async () => (await supabase.from("pelanggaran" as any).select("*").eq("student_id", active.id).order("date", { ascending: false })).data ?? [],
  });

  const totalPoin = (pelanggaran ?? []).reduce((a: number, p: any) => a + (p.poin ?? 0), 0);
  const juzLulus = new Set((exams ?? []).filter((e: any) => e.passed).map((e: any) => e.juz)).size;

  const signOut = async () => {
    await qc.cancelQueries(); qc.clear();
    await supabase.auth.signOut();
    nav({ to: "/auth", replace: true });
  };

  return (
    <div className="min-h-screen bg-muted/30">
      <header className="sticky top-0 z-20 flex items-center justify-between border-b bg-background/80 px-4 py-3 backdrop-blur">
        <div className="flex items-center gap-2 font-display text-lg font-extrabold">
          <img src={logoSaqu.url} alt="SAQU" className="h-8 w-8 object-contain" />Portal Wali Santri
        </div>
        <Button variant="outline" size="sm" className="rounded-xl" onClick={signOut}><LogOut className="mr-2 h-4 w-4" />Keluar</Button>
      </header>

      <main className="mx-auto max-w-3xl px-4 py-6 space-y-4">
        {list.length === 0 && (
          <Card className="card-fun"><CardContent className="p-6 text-center text-sm text-muted-foreground">
            Akun Anda belum dihubungkan ke data santri. Hubungi admin sekolah untuk menghubungkan akun ini ke anak Anda.
          </CardContent></Card>
        )}

        {list.length > 1 && (
          <Select value={active?.id} onValueChange={setStudentId}>
            <SelectTrigger className="w-full"><SelectValue placeholder="Pilih anak" /></SelectTrigger>
            <SelectContent>{list.map((s: any) => <SelectItem key={s.id} value={s.id}>{s.full_name}</SelectItem>)}</SelectContent>
          </Select>
        )}

        {active && (
          <>
            <Card className="card-fun">
              <CardContent className="flex items-center gap-4 p-5">
                {photoUrl ? <img src={photoUrl} className="h-16 w-16 rounded-2xl object-cover" /> : (
                  <div className="grid h-16 w-16 place-items-center rounded-2xl bg-gradient-to-br from-sky to-leaf text-3xl">{active.gender === "L" ? "👦" : "👧"}</div>
                )}
                <div>
                  <div className="font-display text-xl font-extrabold">{active.full_name}</div>
                  <div className="text-sm text-muted-foreground">NISN {active.nis} · Kelas {active.class_level} · {active.halaqoh?.name ?? "Belum ada halaqoh"}</div>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-2 gap-3">
              <Card className="card-fun"><CardContent className="p-4 text-center">
                <GraduationCap className="mx-auto h-6 w-6 text-sky mb-1" />
                <div className="text-2xl font-extrabold">{juzLulus}</div>
                <div className="text-xs text-muted-foreground">Juz Lulus (Target {active.target_juz})</div>
              </CardContent></Card>
              <Card className="card-fun"><CardContent className="p-4 text-center">
                <AlertTriangle className="mx-auto h-6 w-6 text-berry mb-1" />
                <div className="text-2xl font-extrabold">{totalPoin}</div>
                <div className="text-xs text-muted-foreground">Total Poin Pelanggaran</div>
              </CardContent></Card>
            </div>

            <Card className="card-fun">
              <CardHeader><CardTitle className="flex items-center gap-2"><Heart className="h-5 w-5 text-berry" />Buku Penghubung (14 hari terakhir)</CardTitle></CardHeader>
              <CardContent className="space-y-2">
                {(buku ?? []).length === 0 && <p className="text-sm text-muted-foreground">Belum ada catatan buku penghubung.</p>}
                {(buku ?? []).map((b: any) => {
                  const shalatCount = [b.shalat_subuh, b.shalat_dzuhur, b.shalat_ashar, b.shalat_maghrib, b.shalat_isya].filter(Boolean).length;
                  return (
                    <div key={b.id} className="rounded-xl border bg-muted/20 px-3 py-2 text-sm">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold">{b.date}</span>
                        <span className="text-xs text-muted-foreground">Shalat {shalatCount}/5 · Tilawah {b.tilawah_rumah ? "✓" : "-"}</span>
                      </div>
                      {b.kebaikan && <p className="text-xs mt-1">💚 {b.kebaikan}</p>}
                    </div>
                  );
                })}
              </CardContent>
            </Card>

            <Card className="card-fun">
              <CardHeader><CardTitle className="flex items-center gap-2"><AlertTriangle className="h-5 w-5 text-berry" />Catatan Pelanggaran</CardTitle></CardHeader>
              <CardContent className="space-y-2">
                {(pelanggaran ?? []).length === 0 && <p className="text-sm text-muted-foreground">Alhamdulillah, belum ada catatan pelanggaran.</p>}
                {(pelanggaran ?? []).map((p: any) => (
                  <div key={p.id} className="rounded-xl border bg-muted/20 px-3 py-2 text-sm">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold">{p.jenis}</span>
                      <span className="rounded-full bg-berry/20 px-2 py-0.5 text-xs font-bold text-berry">-{p.poin} poin</span>
                    </div>
                    <div className="text-xs text-muted-foreground">{p.date}{p.catatan ? ` · ${p.catatan}` : ""}</div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="card-fun">
              <CardHeader><CardTitle className="flex items-center gap-2"><BookOpen className="h-5 w-5 text-sky" />Ujian Tahfidz Terakhir</CardTitle></CardHeader>
              <CardContent className="space-y-2">
                {(exams ?? []).length === 0 && <p className="text-sm text-muted-foreground">Belum ada ujian.</p>}
                {(exams ?? []).slice(0, 5).map((e: any) => (
                  <div key={e.id} className="flex items-center justify-between rounded-xl border bg-muted/20 px-3 py-2 text-sm">
                    <span>{e.date} · Juz {e.juz}</span>
                    <span className={`rounded-full px-2 py-0.5 text-xs font-bold ${e.passed ? "bg-leaf/20 text-leaf" : "bg-muted text-muted-foreground"}`}>{e.passed ? "Lulus" : "Belum Lulus"}</span>
                  </div>
                ))}
              </CardContent>
            </Card>
          </>
        )}
      </main>
    </div>
  );
}
