import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ChevronLeft, ChevronRight, Loader2 } from "lucide-react";
import { SURAHS } from "@/lib/quran";

type Ayat = { nomorAyat: number; teksArab: string };
type SurahDetail = { nomor: number; nama: string; namaLatin: string; ayat: Ayat[] };

function toArabicNum(n: number): string {
  const d = "٠١٢٣٤٥٦٧٨٩";
  return String(n).split("").map((c) => d[+c] ?? c).join("");
}

async function fetchSurahDetail(nomor: number): Promise<SurahDetail> {
  const r = await fetch(`https://equran.id/api/v2/surat/${nomor}`);
  if (!r.ok) throw new Error("Gagal memuat surah");
  const j = await r.json();
  return j.data;
}

const LINES_PER_PAGE = 15;
const CHARS_PER_LINE = 42; // estimasi karakter Uthmani per baris pada lebar kolom mushaf standar

/** Bagi ayat-ayat surah menjadi "halaman" berisi ±15 baris, berdasarkan estimasi panjang teks. */
function paginate(ayat: Ayat[]): Ayat[][] {
  const pages: Ayat[][] = [];
  let current: Ayat[] = [];
  let lines = 0;
  for (const a of ayat) {
    const estLines = Math.max(1, Math.ceil(a.teksArab.length / CHARS_PER_LINE));
    if (lines + estLines > LINES_PER_PAGE && current.length > 0) {
      pages.push(current);
      current = [];
      lines = 0;
    }
    current.push(a);
    lines += estLines;
  }
  if (current.length) pages.push(current);
  return pages.length ? pages : [[]];
}

export function MushafTeksViewer({ initialSurah = 1 }: { initialSurah?: number }) {
  const [surahNo, setSurahNo] = useState(initialSurah);
  const [pageIdx, setPageIdx] = useState(0);

  const { data: surah, isLoading } = useQuery({
    queryKey: ["mushaf-teks-surat", surahNo],
    queryFn: () => fetchSurahDetail(surahNo),
    staleTime: 1000 * 60 * 60,
  });

  const pages = useMemo(() => (surah ? paginate(surah.ayat) : [[]]), [surah]);
  const page = pages[Math.min(pageIdx, pages.length - 1)] ?? [];
  const surahMeta = SURAHS.find((s) => s.no === surahNo);

  const goSurah = (n: number) => {
    const next = Math.max(1, Math.min(114, n));
    setSurahNo(next);
    setPageIdx(0);
  };

  const nextPage = () => {
    if (pageIdx < pages.length - 1) setPageIdx(pageIdx + 1);
    else goSurah(surahNo + 1);
  };
  const prevPage = () => {
    if (pageIdx > 0) setPageIdx(pageIdx - 1);
    else if (surahNo > 1) { setSurahNo(surahNo - 1); setPageIdx(9999); }
  };

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-sm font-semibold text-muted-foreground">
          {surahMeta?.name} · Halaman Teks {pageIdx + 1}/{pages.length}
        </div>
        <div className="flex items-center gap-2">
          <Select value={String(surahNo)} onValueChange={(v) => goSurah(+v)}>
            <SelectTrigger className="w-44 h-9"><SelectValue placeholder="Surah" /></SelectTrigger>
            <SelectContent className="max-h-64">
              {SURAHS.map((s) => <SelectItem key={s.no} value={String(s.no)}>{s.no}. {s.name}</SelectItem>)}
            </SelectContent>
          </Select>
          <Button size="sm" variant="outline" className="rounded-lg" onClick={prevPage} disabled={surahNo <= 1 && pageIdx <= 0}><ChevronLeft className="h-4 w-4" /></Button>
          <Button size="sm" variant="outline" className="rounded-lg" onClick={nextPage} disabled={surahNo >= 114 && pageIdx >= pages.length - 1}><ChevronRight className="h-4 w-4" /></Button>
        </div>
      </div>

      <div className="relative bg-[oklch(0.97_0.02_90)] p-6 rounded-xl border overflow-hidden" style={{ minHeight: 240 }}>
        {isLoading ? (
          <div className="flex flex-col items-center justify-center gap-2 text-muted-foreground text-sm py-16">
            <Loader2 className="h-6 w-6 animate-spin" />Memuat teks surah…
          </div>
        ) : (
          <>
            {pageIdx === 0 && surahNo !== 1 && surahNo !== 9 && (
              <p dir="rtl" className="font-arabic text-2xl text-center leading-loose text-foreground mb-4">
                بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
              </p>
            )}
            <p dir="rtl" lang="ar" className="font-arabic text-3xl leading-[2.6] text-justify text-foreground">
              {page.map((a) => (
                <span key={a.nomorAyat}>
                  {a.teksArab}{" "}
                  <span className="text-leaf text-xl">﴿{toArabicNum(a.nomorAyat)}﴾</span>{" "}
                </span>
              ))}
            </p>
          </>
        )}
      </div>
      <p className="text-xs text-muted-foreground text-center">
        Teks Al-Qur'an rasm Uthmani · dimuat langsung dari equran.id (Kemenag RI) · ±15 baris per halaman
      </p>
    </div>
  );
}
