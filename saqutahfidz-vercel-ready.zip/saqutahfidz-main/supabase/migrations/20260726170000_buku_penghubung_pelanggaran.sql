-- ===== Buku Penghubung (shalat, tilawah, perbuatan baik) =====
CREATE TABLE public.buku_penghubung (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  shalat_subuh BOOLEAN NOT NULL DEFAULT false,
  shalat_dzuhur BOOLEAN NOT NULL DEFAULT false,
  shalat_ashar BOOLEAN NOT NULL DEFAULT false,
  shalat_maghrib BOOLEAN NOT NULL DEFAULT false,
  shalat_isya BOOLEAN NOT NULL DEFAULT false,
  tilawah_rumah BOOLEAN NOT NULL DEFAULT false,
  kebaikan TEXT,
  recorded_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (student_id, date)
);

ALTER TABLE public.buku_penghubung ENABLE ROW LEVEL SECURITY;

CREATE POLICY buku_penghubung_admin_all ON public.buku_penghubung
  FOR ALL TO authenticated
  USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));

CREATE POLICY buku_penghubung_musyrif_write ON public.buku_penghubung
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'musyrif'::public.app_role) AND public.is_musyrif_of_student(auth.uid(), student_id))
  WITH CHECK (public.has_role(auth.uid(), 'musyrif'::public.app_role) AND public.is_musyrif_of_student(auth.uid(), student_id));

CREATE POLICY buku_penghubung_musyrif_read ON public.buku_penghubung
  FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'musyrif'::public.app_role));

CREATE POLICY buku_penghubung_wali_read ON public.buku_penghubung
  FOR SELECT TO authenticated
  USING (public.is_parent_of_student(auth.uid(), student_id));

-- ===== Poin Pelanggaran =====
CREATE TABLE public.pelanggaran (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  jenis TEXT NOT NULL,
  poin INT NOT NULL DEFAULT 1,
  catatan TEXT,
  recorded_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.pelanggaran ENABLE ROW LEVEL SECURITY;

CREATE POLICY pelanggaran_admin_all ON public.pelanggaran
  FOR ALL TO authenticated
  USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));

CREATE POLICY pelanggaran_musyrif_write ON public.pelanggaran
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'musyrif'::public.app_role) AND public.is_musyrif_of_student(auth.uid(), student_id))
  WITH CHECK (public.has_role(auth.uid(), 'musyrif'::public.app_role) AND public.is_musyrif_of_student(auth.uid(), student_id));

CREATE POLICY pelanggaran_musyrif_read ON public.pelanggaran
  FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'musyrif'::public.app_role));

CREATE POLICY pelanggaran_wali_read ON public.pelanggaran
  FOR SELECT TO authenticated
  USING (public.is_parent_of_student(auth.uid(), student_id));

-- ===== Lookup NISN publik (terbatas) untuk pendaftaran akun Wali Santri =====
CREATE OR REPLACE FUNCTION public.nisn_lookup(_nis TEXT)
RETURNS TABLE(id UUID, full_name TEXT)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT id, full_name FROM public.students WHERE nis = _nis LIMIT 1
$$;
GRANT EXECUTE ON FUNCTION public.nisn_lookup(TEXT) TO anon, authenticated;
