# SAQU Mutaba'ah Tahfidz

Aplikasi pemantauan hafalan Al-Qur'an untuk sekolah dasar — setoran ziyadah,
muroja'ah, tasmi', ujian tahfidz, mushaf digital, absensi, target juz, dan
rapor santri.

## Tumpukan teknologi

- [TanStack Start](https://tanstack.com/start) (React 19, SSR)
- TypeScript
- Tailwind CSS
- [Supabase](https://supabase.com) (database, auth, storage)

## Pengembangan lokal

Butuh Node.js 20+ dan npm.

```sh
git clone <url-repository-ini>
cd <nama-repository>
npm install
```

Buat file `.env` di root project berisi variabel Supabase berikut (lihat
"Environment variables" di bawah), lalu jalankan:

```sh
npm run dev
```

## Environment variables

| Variabel | Dipakai di | Keterangan |
| --- | --- | --- |
| `VITE_SUPABASE_URL` | client & SSR | URL project Supabase |
| `VITE_SUPABASE_PUBLISHABLE_KEY` | client & SSR | Publishable/anon key Supabase |
| `SUPABASE_URL` | server | Sama dengan `VITE_SUPABASE_URL`, dipakai di server functions |
| `SUPABASE_PUBLISHABLE_KEY` | server | Sama dengan `VITE_SUPABASE_PUBLISHABLE_KEY` |
| `SUPABASE_SERVICE_ROLE_KEY` | server (admin) | Service role key — **jangan** diekspos ke client |

Ambil nilainya dari **Supabase Dashboard → Project Settings → API**.

Login dengan Google memakai OAuth bawaan Supabase — aktifkan provider Google
di **Supabase Dashboard → Authentication → Providers** dan set redirect URL
sesuai domain deployment Anda.

## Deploy ke Vercel

Project ini di-build dengan [Nitro](https://nitro.build) menggunakan preset
`vercel`, jadi deployment-nya *zero-config*:

1. Push repository ini ke GitHub.
2. Di Vercel, klik **Add New → Project** dan pilih repository ini.
3. Vercel akan mendeteksi build command (`npm run build`) secara otomatis
   lewat `package.json`.
4. Tambahkan environment variables di atas pada **Project Settings →
   Environment Variables**.
5. Deploy.

Migrasi database Supabase ada di `supabase/migrations/` — jalankan lewat
[Supabase CLI](https://supabase.com/docs/guides/cli) (`supabase db push`)
atau tempel manual ke SQL editor Supabase Dashboard.

## Skrip

- `npm run dev` — server pengembangan
- `npm run build` — build produksi (menghasilkan `.vercel/output/`)
- `npm run preview` — preview hasil build secara lokal
- `npm run lint` — ESLint
- `npm run format` — Prettier
