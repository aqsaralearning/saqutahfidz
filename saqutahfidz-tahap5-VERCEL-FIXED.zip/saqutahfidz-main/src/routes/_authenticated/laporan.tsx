import { createFileRoute } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, CartesianGrid, LineChart, Line } from "recharts";
import { Trophy, Download, FileDown, Medal } from "lucide-react";
import { useMemo, useState } from "react";
import { generateRaporPDF, generateRekapPeriodePDF } from "@/lib/report-pdf";

export const Route = createFileRoute("/_authenticated/laporan")({
  head: () => ({ meta: [{ title: "Laporan — SAQU Tahfidz" }] }),
  component: Laporan,
});

type Periode = "mingguan" | "bulanan" | "semester" | "semua";
const PERIODE_LABEL: Record<Periode, string> = {
  mingguan: "7 Hari Terakhir", bulanan: "30 Hari Terakhir", semester: "6 Bulan Terakhir", semua: "Semua Waktu",
};

function periodeStart(p: Periode): string | null {
  const d = new Date();
  if (p === "mingguan") d.setDate(d.getDate() - 7);
  else if (p === "bulanan") d.setDate(d.getDate() - 30);
  else if (p === "semester") d.setMonth(d.getMonth() - 6);
  else return null;
  return d.toISOString().slice(0, 10);
}

function Laporan() {
  const [periode, setPeriode] = useState<Periode>("bulanan");
  const [scope, setScope] = useState<"semua" | "individu">("semua");
  const [studentId, setStudentId] = useState("");
  const startDate = periodeStart(periode);

  const { data: leaderboard } = useQuery({
    queryKey: ["leaderboard"],
    queryFn: async () => {
      const { data } = await supabase.from("exams").select("student_id, juz, passed, students(full_name)").eq("passed", true);
      const map = new Map<string, { name: string; juz: Set<number> }>();
      (data ?? []).forEach((e: any) => {
        const cur = map.get(e.student_id) ?? { name: e.students?.full_name ?? "-", juz: new Set() };
        cur.juz.add(e.juz);
        map.set(e.student_id, cur);
      });
      return Array.from(map.values()).map((x) => ({ name: x.name, juz: x.juz.size })).sort((a, b) => b.juz - a.juz).slice(0, 10);
    },
  });

  const top3 = (leaderboard ?? []).slice(0, 3);

  const { data: monthly } = useQuery({
    queryKey: ["monthly-setoran"],
    queryFn: async () => {
      const { data } = await supabase.from("ziyadah_entries").select("date");
      const map = new Map<string, number>();
      (data ?? []).forEach((r: any) => {
        const m = r.date.slice(0, 7);
        map.set(m, (map.get(m) ?? 0) + 1);
      });
      return Array.from(map.entries()).sort().slice(-6).map(([bulan, ziyadah]) => ({ bulan, ziyadah }));
    },
  });

  const { data: santriList } = useQuery({
    queryKey: ["students-list"],
    queryFn: async () => (await supabase.from("students").select("id, full_name, nis, class_level, target_juz, gender, halaqoh(name)").order("full_name")).data ?? [],
  });

  const { data: rekapData } = useQuery({
    queryKey: ["rekap-periode", periode],
    queryFn: async () => {
      let ziyQ = supabase.from("ziyadah_entries").select("student_id, score");
      let murQ = supabase.from("murojaah_entries").select("student_id, score");
      let tasQ = supabase.from("tasmi_entries").select("student_id, score");
      let tahQ = supabase.from("tahsin_entries" as any).select("student_id, final_score");
      if (startDate) {
        ziyQ = ziyQ.gte("date", startDate); murQ = murQ.gte("date", startDate);
        tasQ = tasQ.gte("date", startDate); tahQ = tahQ.gte("date", startDate);
      }
      const [ziy, mur, tas, tah] = await Promise.all([ziyQ, murQ, tasQ, tahQ]);
      return { ziy: ziy.data ?? [], mur: mur.data ?? [], tas: tas.data ?? [], tah: tah.data ?? [] };
    },
  });

  const rekapRows = useMemo(() => {
    if (!santriList || !rekapData) return [];
    return santriList.map((s: any) => {
      const ziy = rekapData.ziy.filter((r: any) => r.student_id === s.id);
      const mur = rekapData.mur.filter((r: any) => r.student_id === s.id);
      const tas = rekapData.tas.filter((r: any) => r.student_id === s.id);
      const tah = rekapData.tah.filter((r: any) => r.student_id === s.id);
      const allScores = [...ziy.map((r: any) => r.score), ...mur.map((r: any) => r.score), ...tas.map((r: any) => r.score), ...tah.map((r: any) => r.final_score)]
        .filter((n) => typeof n === "number");
      const rataNilai = allScores.length ? (allScores.reduce((a, b) => a + b, 0) / allScores.length).toFixed(1) : "-";
      return {
        nis: s.nis, nama: s.full_name, halaqoh: s.halaqoh?.name ?? "-",
        ziyadah: ziy.length, murojaah: mur.length, tasmi: tas.length, tahsin: tah.length, rataNilai,
      };
    });
  }, [santriList, rekapData]);

  const exportCSV = () => {
    const head = "nis,nama,halaqoh,ziyadah,murojaah,tasmi,tahsin,rata_rata_nilai";
    const rows = rekapRows.map((r) => [r.nis, r.nama, r.halaqoh, r.ziyadah, r.murojaah, r.tasmi, r.tahsin, r.rataNilai].join(","));
    const csv = [head, ...rows].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = `rekap-tahfidz-${periode}-${new Date().toISOString().slice(0,10)}.csv`; a.click();
    URL.revokeObjectURL(url);
  };

  const exportPDF = () => generateRekapPeriodePDF(rekapRows, PERIODE_LABEL[periode]);

  const exportRaporIndividu = async () => {
    const s = (santriList ?? []).find((x: any) => x.id === studentId);
    if (!s) return;
    let ziyQ = supabase.from("ziyadah_entries").select("*").eq("student_id", studentId);
    let murQ = supabase.from("murojaah_entries").select("*").eq("student_id", studentId);
    let tasQ = supabase.from("tasmi_entries").select("*").eq("student_id", studentId);
    if (startDate) { ziyQ = ziyQ.gte("date", startDate); murQ = murQ.gte("date", startDate); tasQ = tasQ.gte("date", startDate); }
    const [ziy, mur, tas, exams] = await Promise.all([
      ziyQ.order("date", { ascending: false }), murQ.order("date", { ascending: false }),
      tasQ.order("date", { ascending: false }),
      supabase.from("exams").select("*").eq("student_id", studentId).order("date", { ascending: false }),
    ]);
    generateRaporPDF(s, ziy.data ?? [], mur.data ?? [], tas.data ?? [], exams.data ?? []);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-extrabold">Laporan & Rekap</h1>
        <p className="text-muted-foreground">Rekap pencapaian, ranking, dan ekspor data.</p>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="card-fun">
          <CardHeader><CardTitle className="flex items-center gap-2"><Trophy className="text-sun" /> Reward Ranking — Juz Terbanyak Lulus</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            {top3.length === 0 ? (
              <p className="text-sm text-muted-foreground">Belum ada ujian yang lulus.</p>
            ) : (
              <div className="grid grid-cols-3 gap-3 text-center">
                {[1, 0, 2].map((idx) => {
                  const item = top3[idx];
                  if (!item) return <div key={idx} />;
                  const rank = idx + 1;
                  const medal = rank === 1 ? "🥇" : rank === 2 ? "🥈" : "🥉";
                  const ring = rank === 1 ? "ring-2 ring-sun order-2 scale-105" : rank === 2 ? "order-1" : "order-3";
                  return (
                    <div key={idx} className={`card-fun rounded-2xl p-3 ${ring}`}>
                      <div className="text-3xl">{medal}</div>
                      <div className="font-display font-extrabold text-sm mt-1 truncate">{item.name}</div>
                      <div className="text-xs text-muted-foreground">{item.juz} Juz Lulus</div>
                    </div>
                  );
                })}
              </div>
            )}
            {(leaderboard ?? []).length > 3 && (
              <div className="h-56">
                <ResponsiveContainer><BarChart data={leaderboard} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                  <XAxis type="number" allowDecimals={false} /><YAxis dataKey="name" type="category" width={130} />
                  <Tooltip /><Bar dataKey="juz" fill="oklch(0.68 0.16 155)" radius={[0, 8, 8, 0]} />
                </BarChart></ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="card-fun">
          <CardHeader><CardTitle>Tren Setoran Ziyadah (6 bulan)</CardTitle></CardHeader>
          <CardContent className="h-72">
            {(monthly ?? []).length === 0 ? (
              <div className="grid h-full place-items-center text-sm text-muted-foreground">Belum ada data.</div>
            ) : (
              <ResponsiveContainer><LineChart data={monthly}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                <XAxis dataKey="bulan" /><YAxis allowDecimals={false} /><Tooltip />
                <Line type="monotone" dataKey="ziyadah" stroke="oklch(0.58 0.19 250)" strokeWidth={3} />
              </LineChart></ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>

      <Card className="card-fun">
        <CardHeader><CardTitle className="flex items-center gap-2"><Medal className="h-5 w-5 text-berry" />Rekap Tahfidz</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-wrap items-end gap-3">
            <div>
              <Label>Periode</Label>
              <Select value={periode} onValueChange={(v) => setPeriode(v as Periode)}>
                <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="mingguan">Mingguan</SelectItem>
                  <SelectItem value="bulanan">Bulanan</SelectItem>
                  <SelectItem value="semester">Semester</SelectItem>
                  <SelectItem value="semua">Semua Waktu</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Cakupan</Label>
              <Select value={scope} onValueChange={(v) => setScope(v as any)}>
                <SelectTrigger className="w-52"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="semua">Semua Santri</SelectItem>
                  <SelectItem value="individu">Per Santri (Rapor)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {scope === "individu" && (
              <div className="min-w-56">
                <Label>Santri</Label>
                <Select value={studentId} onValueChange={setStudentId}>
                  <SelectTrigger><SelectValue placeholder="Pilih santri" /></SelectTrigger>
                  <SelectContent className="max-h-72">{(santriList ?? []).map((s: any) => <SelectItem key={s.id} value={s.id}>{s.full_name} ({s.nis})</SelectItem>)}</SelectContent>
                </Select>
              </div>
            )}
            <div className="flex gap-2">
              {scope === "semua" ? (
                <>
                  <Button variant="outline" className="rounded-xl" onClick={exportPDF}><FileDown className="mr-2 h-4 w-4" />Unduh PDF</Button>
                  <Button variant="outline" className="rounded-xl" onClick={exportCSV}><Download className="mr-2 h-4 w-4" />Unduh CSV</Button>
                </>
              ) : (
                <Button variant="outline" className="rounded-xl" disabled={!studentId} onClick={exportRaporIndividu}><FileDown className="mr-2 h-4 w-4" />Unduh Rapor PDF</Button>
              )}
            </div>
          </div>

          {scope === "semua" && (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-left text-xs uppercase text-muted-foreground border-b">
                  <tr><th className="py-2 pr-2">NIS</th><th>Nama</th><th>Halaqoh</th><th>Ziyadah</th><th>Muroja'ah</th><th>Tasmi'</th><th>Tahsin</th><th>Rata-rata</th></tr>
                </thead>
                <tbody>
                  {rekapRows.map((r) => (
                    <tr key={r.nis} className="border-b last:border-0">
                      <td className="py-2 pr-2 font-mono text-xs">{r.nis}</td>
                      <td className="font-semibold">{r.nama}</td>
                      <td>{r.halaqoh}</td>
                      <td>{r.ziyadah}</td>
                      <td>{r.murojaah}</td>
                      <td>{r.tasmi}</td>
                      <td>{r.tahsin}</td>
                      <td><span className="rounded-full bg-leaf/20 px-2 py-0.5 text-xs font-bold text-leaf">{r.rataNilai}</span></td>
                    </tr>
                  ))}
                  {rekapRows.length === 0 && <tr><td colSpan={8} className="py-4 text-center text-muted-foreground">Belum ada data.</td></tr>}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
