# SAQU Tahfidz — Siap Deploy Vercel

## Perbaikan utama
- Login Google tidak lagi memakai endpoint internal Lovable `/~oauth/initiate`.
- Login memakai Supabase Auth langsung.
- Ditambahkan login email/password, pendaftaran, lupa password, dan pembuatan password baru.
- Logo dipindah ke `public/logo-saqu.png`, sehingga tidak lagi memakai URL asset internal Lovable.
- Build memakai preset Nitro Vercel.

## Environment Variables di Vercel
Masukkan nilai dari file `.env`:
- `SUPABASE_URL`
- `SUPABASE_PUBLISHABLE_KEY`
- `SUPABASE_PROJECT_ID`
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_PUBLISHABLE_KEY`
- `VITE_SUPABASE_PROJECT_ID`

## Cara masuk paling cepat
1. Buka `/auth`.
2. Jika email sudah pernah dipakai melalui Google/GitHub tetapi tidak punya password, klik **Lupa kata sandi**.
3. Buka email reset, buat password baru, lalu masuk memakai email + password.
4. Bila email belum pernah terdaftar, pilih **Daftar**.

## Domain
Tambahkan `sekolahalamcilaku.my.id` di Vercel > Project > Settings > Domains. Ikuti record DNS yang ditampilkan Vercel pada penyedia domain Anda.
