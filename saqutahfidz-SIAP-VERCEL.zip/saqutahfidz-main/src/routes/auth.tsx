import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";

const logoSaqu = "/logo-saqu.png";

export const Route = createFileRoute("/auth")({
  validateSearch: (s: Record<string, unknown>) => ({
    next: typeof s.next === "string" && s.next.startsWith("/") && !s.next.startsWith("//") ? s.next : "",
  }),
  head: () => ({
    meta: [
      { title: "Masuk — SAQU Mutaba'ah Tahfidz" },
      { name: "description", content: "Masuk atau daftar untuk mengakses aplikasi mutaba'ah tahfidz SAQU." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const nav = useNavigate();
  const { next } = Route.useSearch();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);
  const [mode, setMode] = useState<"signin" | "signup" | "forgot" | "reset">("signin");

  const goNext = () => {
    const destination = next || "/dashboard";
    window.location.assign(destination);
  };

  useEffect(() => {
    const hash = new URLSearchParams(window.location.hash.replace(/^#/, ""));
    const query = new URLSearchParams(window.location.search);
    const isRecovery = hash.get("type") === "recovery" || query.get("type") === "recovery";
    if (isRecovery) setMode("reset");

    supabase.auth.getSession().then(({ data }) => {
      if (data.session && !isRecovery) goNext();
    });

    const { data: listener } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "PASSWORD_RECOVERY") {
        setMode("reset");
        return;
      }
      if (event === "SIGNED_IN" && session && !isRecovery) goNext();
    });
    return () => listener.subscription.unsubscribe();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const validate = () => {
    if (!email.trim()) { toast.error("Masukkan alamat email."); return false; }
    if (mode !== "forgot" && password.length < 6) { toast.error("Kata sandi minimal 6 karakter."); return false; }
    return true;
  };

  const signIn = async () => {
    if (!validate()) return;
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    setLoading(false);
    if (error) {
      const message = error.message.toLowerCase().includes("invalid login")
        ? "Email atau kata sandi salah. Bila akun sebelumnya dibuat lewat Google/GitHub, gunakan Lupa kata sandi untuk membuat password."
        : error.message;
      toast.error(message);
      return;
    }
    toast.success("Berhasil masuk");
    goNext();
  };

  const signUp = async () => {
    if (!validate()) return;
    if (!name.trim()) return toast.error("Masukkan nama lengkap.");
    setLoading(true);
    const { data, error } = await supabase.auth.signUp({
      email: email.trim(),
      password,
      options: {
        emailRedirectTo: `${window.location.origin}/auth?next=${encodeURIComponent(next || "/dashboard")}`,
        data: { full_name: name.trim() },
      },
    });
    setLoading(false);
    if (error) {
      if (error.message.toLowerCase().includes("already")) {
        toast.error("Email sudah terdaftar. Gunakan Masuk atau Lupa kata sandi.");
        setMode("signin");
      } else toast.error(error.message);
      return;
    }
    if (data.session) {
      toast.success("Akun berhasil dibuat.");
      goNext();
    } else {
      toast.success("Pendaftaran berhasil. Periksa email untuk konfirmasi, lalu masuk.");
      setMode("signin");
    }
  };

  const forgotPassword = async () => {
    if (!email.trim()) return toast.error("Masukkan email terlebih dahulu.");
    setLoading(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), {
      redirectTo: `${window.location.origin}/auth?type=recovery`,
    });
    setLoading(false);
    if (error) return toast.error(error.message);
    toast.success("Tautan pengaturan ulang kata sandi sudah dikirim. Periksa Inbox dan Spam.");
  };

  const updatePassword = async () => {
    if (password.length < 6) return toast.error("Kata sandi minimal 6 karakter.");
    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password });
    setLoading(false);
    if (error) return toast.error(error.message);
    toast.success("Kata sandi berhasil dibuat. Silakan masuk.");
    await supabase.auth.signOut();
    setPassword("");
    setMode("signin");
  };

  const google = async () => {
    setLoading(true);
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: { redirectTo: `${window.location.origin}${next || "/dashboard"}` },
    });
    if (error) {
      setLoading(false);
      toast.error(`Login Google belum aktif di backend: ${error.message}. Gunakan email dan kata sandi.`);
    }
  };

  return (
    <div className="min-h-screen gradient-hero flex items-center justify-center px-4 py-10">
      <Card className="w-full max-w-md card-fun">
        <CardHeader className="text-center">
          <Link to="/" className="mx-auto block h-20 w-20"><img src={logoSaqu} alt="SAQU" className="h-20 w-20 object-contain" /></Link>
          <CardTitle className="mt-2 font-display text-2xl">SAQU Tahfidz</CardTitle>
          <p className="text-sm text-muted-foreground">Masuk untuk mengakses aplikasi mutaba'ah</p>
        </CardHeader>
        <CardContent>
          {mode === "forgot" ? (
            <div className="space-y-4">
              <div><Label>Email akun</Label><Input type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} /></div>
              <Button className="w-full rounded-xl" onClick={forgotPassword} disabled={loading}>{loading ? "Mengirim..." : "Kirim tautan reset"}</Button>
              <Button variant="ghost" className="w-full" onClick={() => setMode("signin")}>Kembali ke halaman masuk</Button>
            </div>
          ) : mode === "reset" ? (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">Buat kata sandi baru untuk akun Anda.</p>
              <div><Label>Kata sandi baru</Label><Input type="password" autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} /></div>
              <Button className="w-full rounded-xl" onClick={updatePassword} disabled={loading}>{loading ? "Menyimpan..." : "Simpan kata sandi baru"}</Button>
            </div>
          ) : (
            <>
              <Tabs value={mode} onValueChange={(v) => setMode(v as "signin" | "signup")}>
                <TabsList className="grid w-full grid-cols-2 rounded-xl">
                  <TabsTrigger value="signin">Masuk</TabsTrigger>
                  <TabsTrigger value="signup">Daftar</TabsTrigger>
                </TabsList>
                <TabsContent value="signin" className="space-y-3 pt-4">
                  <div><Label>Email</Label><Input type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} /></div>
                  <div><Label>Kata sandi</Label><Input type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} onKeyDown={(e) => e.key === "Enter" && signIn()} /></div>
                  <Button className="w-full rounded-xl" onClick={signIn} disabled={loading}>{loading ? "Memproses..." : "Masuk"}</Button>
                  <button type="button" onClick={() => setMode("forgot")} className="w-full text-center text-sm text-primary hover:underline">Lupa kata sandi?</button>
                </TabsContent>
                <TabsContent value="signup" className="space-y-3 pt-4">
                  <div><Label>Nama lengkap</Label><Input autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} /></div>
                  <div><Label>Email</Label><Input type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} /></div>
                  <div><Label>Kata sandi</Label><Input type="password" autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} /></div>
                  <Button className="w-full rounded-xl" onClick={signUp} disabled={loading}>{loading ? "Memproses..." : "Buat akun"}</Button>
                  <p className="text-xs text-muted-foreground">Jika email sudah pernah digunakan lewat Google/GitHub, buka tab Masuk lalu pilih Lupa kata sandi.</p>
                </TabsContent>
              </Tabs>
              <div className="my-4 flex items-center gap-3 text-xs text-muted-foreground"><span className="h-px flex-1 bg-border" />atau<span className="h-px flex-1 bg-border" /></div>
              <Button variant="outline" className="w-full rounded-xl" onClick={google} disabled={loading}>
                <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.5h5.9c-.3 1.4-1 2.6-2.2 3.4v2.8h3.6c2.1-1.9 3.2-4.7 3.2-8.4z"/><path fill="#34A853" d="M12 23c3 0 5.5-1 7.3-2.7l-3.6-2.8c-1 .7-2.3 1.1-3.7 1.1-2.9 0-5.3-1.9-6.2-4.6H2.1v2.9C3.9 20.5 7.6 23 12 23z"/><path fill="#FBBC05" d="M5.8 14c-.2-.7-.4-1.4-.4-2.1s.1-1.4.4-2.1V6.9H2.1C1.4 8.4 1 10.1 1 12s.4 3.6 1.1 5.1L5.8 14z"/><path fill="#EA4335" d="M12 5.4c1.6 0 3.1.6 4.3 1.7l3.2-3.2C17.5 2.1 15 1 12 1 7.6 1 3.9 3.5 2.1 6.9L5.8 9.8C6.7 7.1 9.1 5.4 12 5.4z"/></svg>
                Masuk dengan Google
              </Button>
              <p className="mt-3 text-center text-xs text-muted-foreground">Untuk penggunaan tercepat, gunakan email + kata sandi. Login Google memerlukan provider Google aktif di backend.</p>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
